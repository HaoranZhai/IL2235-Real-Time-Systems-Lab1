// main.c — IL2235 Lab1-B (FreeRTOS_Intro)
// 优化版：任务执行完后不立即打印，而是存入缓冲区，
// 在每个超周期（hyperperiod）结束后统一输出，避免UART阻塞。

#include <stdio.h>
#include <inttypes.h>
#include <stdbool.h>

#include "pico/stdlib.h"
#include "bsp.h"

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

#include "../common/workload.h"   // job_A..job_F, jobReturn_t, EXECUTION_TIME_*, CYCLES_PER_US

/* ----------------------- 配置 ----------------------- */
#define USE_DIP_FOR_TASK_C    1
#define UART_BOOT_DELAY_MS    1000
#define TASK_STACK_WORDS      1024

/* -------------------- 任务与优先级（RM） -------------------- */
typedef enum { TA, TB, TC, TD, TE, TF, TASK_CNT } task_id_t;

typedef struct {
    const char *name;
    uint32_t    period_ms;
    UBaseType_t prio;     // 数值越大优先级越高
} task_meta_t;

/* 周期：B=5, A=10, F=20, C=25, D=50, E=50  -> B最高，E/D最低 */
static const task_meta_t META[TASK_CNT] = {
    [TA] = { "Task_A", 10, 4 },
    [TB] = { "Task_B",  5, 5 },
    [TC] = { "Task_C", 25, 2 },
    [TD] = { "Task_D", 50, 1 },
    [TE] = { "Task_E", 50, 1 },
    [TF] = { "Task_F", 20, 3 },
};

static const char *const INAME[TASK_CNT] = {
    [TA]="Task_A",[TB]="Task_B",[TC]="Task_C",
    [TD]="Task_D",[TE]="Task_E",[TF]="Task_F"
};

/* ----------------------- 日志结构 ----------------------- */
typedef struct {
    uint8_t  id;
    uint64_t rel_us;
    uint64_t start_us;
    uint64_t stop_us;
    uint32_t exec_us;
    uint64_t ddl_us;
    uint8_t  miss;
} log_item_t;

/* ----------------------- 全局缓冲区 ----------------------- */
#define LOG_BUF_MAX 1024
static log_item_t g_log_buf[LOG_BUF_MAX];
static volatile uint32_t g_log_cnt = 0;
static SemaphoreHandle_t g_log_lock;

/* ----------------------- 拨码/Task_C ----------------------- */
#if USE_DIP_FOR_TASK_C
static inline uint8_t read_switches8(void) {
    uint8_t v = 0;
    v |= (BSP_GetInput(SW_10) ? 1u:0u) << 0;
    v |= (BSP_GetInput(SW_11) ? 1u:0u) << 1;
    v |= (BSP_GetInput(SW_12) ? 1u:0u) << 2;
    v |= (BSP_GetInput(SW_13) ? 1u:0u) << 3;
    v |= (BSP_GetInput(SW_14) ? 1u:0u) << 4;
    v |= (BSP_GetInput(SW_15) ? 1u:0u) << 5;
    v |= (BSP_GetInput(SW_16) ? 1u:0u) << 6;
    v |= (BSP_GetInput(SW_17) ? 1u:0u) << 7;
    return v;
}

/* 拨码 → 忙等参数 */
#define C_STEP_US        400u
#define C_MAX_EXTRA_US  30000u
#define C_SLICE_US      2000u

static inline void job_C_switch(jobReturn_t* r, uint8_t sw)
{
    r->start = time_us_64();
    uint32_t base_cycles = EXECUTION_TIME_C;

    uint32_t extra_us = (uint32_t)sw * C_STEP_US;
    if (extra_us > C_MAX_EXTRA_US) extra_us = C_MAX_EXTRA_US;

    uint64_t total_cycles =
        (uint64_t)base_cycles + (uint64_t)extra_us * (uint64_t)CYCLES_PER_US;

    const uint32_t slice_cycles = (uint32_t)((uint64_t)C_SLICE_US * (uint64_t)CYCLES_PER_US);

    while (total_cycles) {
        uint32_t this_slice = (total_cycles > slice_cycles) ? slice_cycles : (uint32_t)total_cycles;
        if (this_slice == 0) break;
        BSP_WaitClkCycles(this_slice);
        total_cycles -= this_slice;
    }

    r->stop  = time_us_64();
}
#endif

/* ----------------------- 运行具体 job ----------------------- */
static inline void run_job(task_id_t id, jobReturn_t *r) {
#if USE_DIP_FOR_TASK_C
    if (id == TC) { job_C_switch(r, read_switches8()); return; }
#endif
    switch (id) {
        case TA: job_A(r); break;
        case TB: job_B(r); break;
        case TC: job_C(r); break;
        case TD: job_D(r); break;
        case TE: job_E(r); break;
        case TF: job_F(r); break;
        default: r->start = r->stop = time_us_64(); break;
    }
}

/* ----------------------- 周期任务模板 ----------------------- */
typedef struct { task_id_t id; } task_arg_t;

static void periodic_task(void *arg) {
    const task_id_t   id      = ((task_arg_t*)arg)->id;
    const TickType_t  T_ticks = pdMS_TO_TICKS(META[id].period_ms);
    const uint64_t    T_us    = (uint64_t)META[id].period_ms * 1000ull;

    TickType_t xLastWake      = xTaskGetTickCount();
    uint64_t   next_release_us= time_us_64();

    for (;;) {
        const uint64_t rel = next_release_us;
        const uint64_t ddl = rel + T_us;

        jobReturn_t r;
        run_job(id, &r);

        const uint32_t exec = (uint32_t)(r.stop - r.start);
        const uint8_t  miss = (r.stop > ddl) ? 1u : 0u;

        log_item_t it = {
            .id      = (uint8_t)id,
            .rel_us  = rel,
            .start_us= r.start,
            .stop_us = r.stop,
            .exec_us = exec,
            .ddl_us  = ddl,
            .miss    = miss
        };

        /* ---- 写入缓冲（非阻塞） ---- */
        taskENTER_CRITICAL();
        if (g_log_cnt < LOG_BUF_MAX) {
            g_log_buf[g_log_cnt++] = it;
        }
        taskEXIT_CRITICAL();

        next_release_us += T_us;
        vTaskDelayUntil(&xLastWake, T_ticks);
    }
}

/* ----------------------- Logger 任务 ----------------------- */
/* 超周期长度（LCM of {5,10,20,25,50} = 100ms） */
#define HYPERPERIOD_MS  100

static void logger_task(void *arg) {
    (void)arg;
    const TickType_t H_ticks = pdMS_TO_TICKS(HYPERPERIOD_MS);
    TickType_t xLastWake = xTaskGetTickCount();

    for (;;) {
        /* 等待一个超周期 */
        vTaskDelayUntil(&xLastWake, H_ticks);

        /* 进入临界区复制数据 */
        taskENTER_CRITICAL();
        uint32_t n = g_log_cnt;
        g_log_cnt = 0;
        taskEXIT_CRITICAL();

        printf("\r\n===== Hyperperiod finished (%lu logs) =====\r\n",
               (unsigned long)n);
        for (uint32_t i = 0; i < n; i++) {
            log_item_t *p = &g_log_buf[i];
            printf("%s [rel=%" PRIu64 "] s=%" PRIu64 " e=%" PRIu64
                   " exec=%u %s now=%" PRIu64 " ddl=%" PRIu64 "\r\n",
                   INAME[p->id],
                   p->rel_us, p->start_us, p->stop_us,
                   p->exec_us,
                   p->miss ? "MISS" : "OK",
                   p->stop_us, p->ddl_us);
        }
        fflush(stdout);
    }
}

/* --------------------------- main --------------------------- */
int main(void) {
    BSP_Init();
    stdio_init_all();
    sleep_ms(UART_BOOT_DELAY_MS);

    /* 对齐启动时间 */
    {
        uint64_t t0 = time_us_64();
        uint64_t align = (t0 / 1000ull) * 1000ull + 1000ull;
        while (time_us_64() < align) { tight_loop_contents(); }
    }

    /* 创建互斥锁（保护缓冲区） */
    g_log_lock = xSemaphoreCreateMutex();
    configASSERT(g_log_lock != NULL);

    /* Logger（最低优先级） */
    xTaskCreate(logger_task, "logger", TASK_STACK_WORDS, NULL, tskIDLE_PRIORITY, NULL);

    /* 创建 6 个周期任务（RM 优先级） */
    static task_arg_t args[TASK_CNT];
    for (int i = 0; i < TASK_CNT; ++i) {
        args[i].id = (task_id_t)i;
        BaseType_t ok = xTaskCreate(
            periodic_task,
            META[i].name,
            TASK_STACK_WORDS,
            &args[i],
            META[i].prio,
            NULL
        );
        configASSERT(ok == pdPASS);
    }

    vTaskStartScheduler();
    while (1) { }
    return 0;
}
