# IL2235: Lab 1

## Objective

The goal of this lab is to familiarize yourself with the hardware and software platform we use.
Afterwards, you will create a cyclic scheduler from scratch and configure it to execute a number of tasks.
The second part of the lab will use FreeRTOS (on a single core) and we will execute the same workload as in part A.

## Preparation

1. Read carefully the information on the [Embedded Systems Lab-Kit repository](https://gits-15.sys.kth.se/mabecker/ES-Lab-Kit) and then install the software (note the difference if you install on a lab computer or on your own!).
2. Run the example application as described in the instructions. It covers all important BSP-package functions, and you will use several of them in the laboratory.
3. Clone this repository and place it under `ES_Lab_Kit/Software/` so that it is located under `ES_Lab_Kit/Software/il2235_lab1/`.

The repository already contains the base projects you will use for Lab1-A and Lab1-B, you can import them directly in VSCode.

## Lab1_A

Lab1_A focuses on cyclic scheduling.
You will implement a cyclic scheduler and configure it to execute a set of predefined tasks.

For this lab you will use the prepared project in `ES_Lab_Kit/Software/il2235_lab1/CyclicSched`.
The files `ES_Lab_Kit/Software/il2235_lab1/common/workload.c` and `ES_Lab_Kit/Software/il2235_lab1/common/workload.h` contain dummy workload that we aim to schedule.
Note that they are located outside the folder `CyclicSched` since we use the same functions on part A and B.
Each job first prints the current system time (in ns), executes some dummy workload, and prints the current system time again.
As a convention, we say that `job_A()` is a job of `Task A`.

The following table includes all task periods.
We assume that each task has an implicit deadline (i.e. T=D)

| Task   | Period |
|--------|--------|
| Task_A | 10 ms  |
| Task_B | 5 ms   |
| Task_C | 25 ms  |
| Task_D | 50 ms |
| Task_E | 50 ms  |
| Task_F | 20 ms  |

### Determine the execution times of all tasks

In order to construct the cyclic schedule, we need to know task exeuction times, as well as periods.
The periods are already known (see table above).
Here, we try to experimentally obtain an estimate of the execution times.

Each task body consists of three parts.
* Print of the current system time to the console
* Execute a number of CPU cycles (polling)
* Print of the current system time to the console

Determine experimentally the execution time of each task.

**Hint:** You can obtain the current system time using the function `time_us_64()`.

### Implement a cyclic scheduler

Implement the mechanisms needed for a cyclic scheduler (see lecture slides).
The cyclic scheduler shall be designed in such a way that it is easy to configure the schedule.

#### Repeating Timer
You can add a repeating timer using the function `add_repeating_timer_ms(...)` (see [here](https://www.raspberrypi.com/documentation/pico-sdk/high_level.html#group_repeating_timer_1ga02133dbe7083fcf3c7392a2cfb8243ba)).

**Example:**
Creates a repeating timer to toggle the red LED every 1000ms.
```
repeating_timer_t tmr;

bool timer_callback(repeating_timer_t *tmr) {
   BSP_ToggleLED(LED_RED);
   return true;
}

void main(void) {
   add_repeating_timer_ms(1000, timer_callback, NULL, &tmr);
}
```

#### Create the schedule

1) Compute the hyperperiod of the taskset (on paper).
2) Determine the largest size of the minor frame that we can configure, based on the three constraints discussed in the lecture (on paper).
3) Assign each job to a frame such that all deadlines are met. Is it possible to find a schedule that meets all deadlines?
4) Transfer the schedule to your implementation.
5) Execute the program and measure start and stop time of each task (given by the printout in the job-code). Does the execution follow the expected behavior?
6) Assume now a task misses its deadline, how can this be detected in the implementation? Extend your implementation to detect deadline misses. Which options do you have to react on a deadline miss? (select one in your implementation)
7) Modify Task_C such that the busy-waiting time is set by the 8 switches on the board. What is the largest switch configuration that still meets all deadlines?  

**Hint:** You can use the BSP function `bool BSP_GetInput(uint32_t gpio)` to read the level of a GPIO pin.

## Lab1-B

Lab 1_B will use FreeRTOS as Real-Time Operating System (RTOS). 
For this lab you will use the prepared project in `ES_Lab_Kit/Software/il2235_lab1/FreeRTOS_Intro`.
This project is configured to include the FreeRTOS sources. A configuration file is prepared in the project folder `FreeRTOSConfig.h`.
We will only use CPU 0 in this lab and FreeRTOS is configured to run only on this core. 

The files `workload.c` and `workload.h` contain the same dummy workload that we used in part A of the lab.
Each job first prints the current system time (in ns), executes some dummy workload, and prints the current system time again.
As before, as a convention, we say that `job_A()` is a job of `Task A`. 
We assume the same period values as in part A.

We now aim to schedule the workload using the RTOS, and examine differences to the cyclic schedule approach of part A. 
Note that the workload we schedule is unchanged, hence the WCET estimates you obtained in part A are still valid. 

### A Template for periodic tasks

All tasks that we want to schedule follow the same release pattern, i.e. the tasks are periodic with implicit deadlines. 
There is no dependency between tasks. 

* Create a function that acts as a template for all periodic tasks in the program. 
You can use a struct-type to hold the necessary task-specific configuration data and give a pointer to the struct as parameter for each task you instantiate. Which parameters do you need to store in the struct?
* Create all tasks in the main function (see the lecture [RTOS Intro](https://canvas.kth.se/courses/57562/pages/real-time-operating-system?module_item_id=1314948)). 
* Task priorities should be assigned according to the Rate Monotonic principle.
### Observing the execution behaviour

* Execute the program and record start and stop time of each task (given by the printout in the job-code). Does the execution follow the expected behavior?
* Study the RTOS configuration to detect why the behavior is maybe different to the expected behaviour (when you draw the schedule). What differences are there?
* Set the parameter `configUSE_TIME_SLICING` in `FreeRTOSConfig.h` to 0 and observe the execution again. What did change?
* What happens if tasks are non-preemptive? Set the parameter `configUSE_PREEMPTION` in `FreeRTOSConfig.h` to 0 and observe the execution again. What did change?
  
### Deadline Misses
* Assume now a task misses its deadline, how can this be detected in the implementation? Extend your implementation to detect deadline misses. Which options do you have to react on a deadline miss? (select one in your implementation)
* Modify Task_C such that the busy-waiting time is set by the 8 switches on the board (use your implementation form part A). What is the largest switch configuration that still meets all deadlines? 

### Comparisson to Linux
Read the blog post [Björn Brandenburg, "Liu and Layland and Linux: A Blueprint for “Proper” Real-Time Tasks" ACM SIGBED Blog, 2020.](https://sigbed.org/2020/09/05/liu-and-layland-and-linux-a-blueprint-for-proper-real-time-tasks/) 
The blog post describes the implementation of periodic tasks on Linux. 

What are the main differences when implementing periodic tasks in FreeRTOS compared to Linux?

## Examination
Demonstrate the programs that you have developed for the laboratory staff during your laboratory session. Be prepared to explain your program in detail and answer the questions of each lab task.

Submit your programs (i.e. the folder IL2235_Lab1) as zip-file in the assignment Lab1 in Canvas.
